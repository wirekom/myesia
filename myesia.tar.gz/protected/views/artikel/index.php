<?php
$this->breadcrumbs=array(
	'Artikels',
);

$this->menu=array(
	array('label'=>'Create Artikel','url'=>array('create')),
	array('label'=>'Manage Artikel','url'=>array('admin')),
);
?>
<script type="text/javascript">
jQuery(document).ready(function() {
	$("a.thumbnail").fancybox({
		'overlayShow'	: true,
		'transitionIn'	: 'elastic',
		'transitionOut'	: 'elastic'
	});
});
</script>
<div class="container inner">
	<div class="row-fluid"><!--========== Content ===========-->
			<h2>HOT NEWS</h2>
		<div class="span3 no-margin krr"><!-- Sebelah Tengah<h3 class="widget-title clearfix">
				<span class="title-text">Terpopuler
					<span class="triangle-right"></span>
					<span class="triangle-left"></span>
					<span class="triangle-bottom"></span>
				</span>
			</h3> -->
			<ul class="populer">
				<li>
					<a href=""><span>PHOTO GALLERY</span></a>
				</li>
				<li>
					<a href=""><span>VIDEO GALLERY</span></a>
				</li>
				<li>
					<a href=""><span>POJOK KOMUNITAS</span></a>
				</li>
				<li>
					<a href=""><span>SECANGKIR KOPI</span></a>
				</li>
				<li>
					<a href=""><span>KUIS</span></a>
				</li>
				<li>
					<a href=""><span>PROFIL KARYAWAN</span></a>
				</li>
				<li>
					<a href=""><span>BERITA KELUARGA</span></a>
				</li>
				<li>
					<a href=""><span>ESIAPEDIA</span></a>
				</li>
			</ul>
		</div>
		<div class="span4"><!-- Sebelah Kiri -->
			<?php $this->widget('bootstrap.widgets.TbListView',array(
				'dataProvider'=>$dataProvider,
				'template'=>"<ul class='list_artikel'>{items}</ul>\n{pager}",
				'itemView'=>'_artikel',
			)); ?>
		</div>
		<div class="span5 knn"><!-- Sebelah Kanan -->
			<div class="singleRev">
			<span class="tangle-left"></span>
			<span class="tangle-bottom"></span>
				<h3 class="tel">Loream Ipsum</h3>
				<span class="iten">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
				Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
				Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</br>
				</br>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
				Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
				Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</span>
				<div class="gbr">
					<img src="<?php echo Yii::app()->request->baseUrl; ?>/images/artikel/Jellyfish.jpg" />
				</div>
			</div>
		</div>
    </div>
</div><!-- /container -->
