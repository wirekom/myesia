<?php
$this->breadcrumbs=array(
	'Artikels'=>array('index'),
	$model->title,
);

$this->menu=array(
	array('label'=>'List Artikel','url'=>array('index')),
	array('label'=>'Create Artikel','url'=>array('create')),
	array('label'=>'Update Artikel','url'=>array('update','id'=>$model->idartikel)),
	array('label'=>'Delete Artikel','url'=>'#','linkOptions'=>array('submit'=>array('delete','id'=>$model->idartikel),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Artikel','url'=>array('admin')),
);
?>

<h1>View Artikel #<?php echo $model->idartikel; ?></h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
	'data'=>$model,
	'attributes'=>array(
		'idartikel',
		'date',
		'title',
		'content',
		'images',
	),
)); ?>
