<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'artikel-form',
	'enableAjaxValidation'=>false,
	'htmlOptions'=>array('enctype'=>'multipart/form-data'),
)); ?>

	<p class="help-block">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<?php echo $form->labelEx($model,'date'); ?>
	<?php $this->widget('zii.widgets.jui.CJuiDatePicker', array(
			'model'=>$model,
			'htmlOptions'=>array('class'=>'span2','maxlength'=>20),
			'attribute'=>'date',
			'value'=>$model->date,
				// additional javascript options for the date picker plugin
			'options'=>array(
				'showAnim'=>'fold',
				'showButtonPanel'=>true,
				'autoSize'=>true,
				'dateFormat'=>'yy-mm-dd',
				'defaultDate'=>$model->date,
				),
			));
		?>

	<?php echo $form->textFieldRow($model,'title',array('class'=>'span5','maxlength'=>225)); ?>

	<?php //echo $form->textAreaRow($model,'content',array('rows'=>6, 'cols'=>50)); ?>
	<?php echo $form->labelEx($model,'content'); ?>
	<?php	Yii::import('ext.krichtexteditor.KRichTextEditor');
			$this->widget('KRichTextEditor', array(
				'model' => $model,
				'htmlOptions'=>array('class'=>'span8'),
				'value' => $model->isNewRecord ? '' : $model->content,
				'attribute' => 'content',
				'options' => array(
					'theme_advanced_resizing' => 'true',
					'theme_advanced_statusbar_location' => 'bottom',
					),
			));?>
	<?php echo $form->fileFieldRow($model,'images',array('class'=>'span5','maxlength'=>150)); ?>

	<div class="form-actions">
		<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			//'type'=>'primary',
			'label'=>$model->isNewRecord ? 'Create' : 'Save',
		)); ?>
	</div>

<?php $this->endWidget(); ?>
