<?php
$this->breadcrumbs=array(
	'Tips & Tricks'=>array('index'),
	$model->title,
);
?>



<div class="container inner">
	<div class="row-fluid"><!--========== Content ===========-->
		<div class="span4">
			<div class="thumb-list">		
				<a href="<?php echo Yii::app()->request->baseUrl."/images/artikel/".$model->images?>" title="<?php echo CHtml::encode($model->title); ?>.">
					<img src="<?php echo Yii::app()->request->baseUrl."/images/artikel/".$model->images?>" />
				</a>
			</div>
		</div>
		<div class="span5"><!-- Sebelah Kiri -->
			<div class="alat">
			<div class="wid-head">
				<h2 class="heading"><?php echo CHtml::encode($model->title); ?></h2>
			</div>
			<div class="wid-body ccd">
				<span id="author" class="margin-none">Date Publish : <?php echo CHtml::encode($model->date); ?></span>
				<div class="media-body">
				<?php echo CHtml::decode($model->content);?>
				</div>
			</div>
		</div>
		</div>
		<div class="span3 knn"><!-- Sebelah Kanan -->
		<div class="babar">
			<h3 class="widget-title clearfix">
				<span class="title-text">Artikel Lainnya
					<span class="triangle-right"></span>
					<span class="triangle-left"></span>
					<span class="triangle-bottom"></span>
				</span>
			</h3>
			<ul class="populer">
				<li>
					<img src="<?php echo Yii::app()->request->baseUrl; ?>/images/featured/image1.jpg" title="" />
					<h3>New Comers</h3>
					<span>PT. Bakrie Telecom, Tbk (BTEL), penyedia layanan telekomunikasi hemat ESIA</br>
						<a href="">Baca lebih lanjut..</a>
					</span>
				</li>
				<li>
					<img src="<?php echo Yii::app()->request->baseUrl; ?>/images/featured/image5.jpg" title="" />
					<h3>Pojok Jajan</h3>
					<span>PT. Bakrie Telecom, Tbk (BTEL), penyedia layanan telekomunikasi hemat ESIA</br>
						<a href="">Baca lebih lanjut..</a>
					</span>
				</li>
				<li>
					<img src="<?php echo Yii::app()->request->baseUrl; ?>/images/featured/image2.jpg" title="" />
					<h3>Morning Coffee</h3>
					<span>PT. Bakrie Telecom, Tbk (BTEL), penyedia layanan telekomunikasi hemat ESIA</br>
						<a href="">Baca lebih lanjut..</a>
					</span>
				</li>
			</ul>
		</div>
		</div>
    </div>
</div><!-- /container -->