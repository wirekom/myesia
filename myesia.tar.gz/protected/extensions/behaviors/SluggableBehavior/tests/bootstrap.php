<?php

require_once __DIR__ . '/../vendor/yiisoft/yii/framework/yii.php';
require_once __DIR__ . '/../SluggableBehavior.php';
